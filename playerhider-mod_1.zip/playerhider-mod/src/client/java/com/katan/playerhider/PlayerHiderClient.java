package com.katan.playerhider;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Klient Fabric moda "Player Hider".
 *
 * Działa WYŁĄCZNIE lokalnie (po stronie klienta): po naciśnięciu przypisanego
 * klawisza inni gracze przestają być renderowani na Twoim ekranie (mechanika
 * identyczna z efektem "Niewidzialność"). Nie wymaga instalacji na serwerze
 * i działa też na cudzym multiplayerze - efekt widzisz tylko Ty.
 */
public class PlayerHiderClient implements ClientModInitializer {

	/** Globalny stan przełącznika - odczytywany przez {@link com.katan.playerhider.mixin.EntityMixin}. */
	public static volatile boolean playersHidden = false;

	private static KeyBinding toggleKeyBinding;

	@Override
	public void onInitializeClient() {
		// Domyślnie klawisz jest NIEPRZYPISANY (GLFW_KEY_UNKNOWN) - przypisz go
		// samodzielnie w: Opcje -> Sterowanie -> zakładka "Player Hider".
		toggleKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.playerhider.toggle",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_UNKNOWN,
				"key.categories.playerhider"
		));

		ClientTickEvents.END_CLIENT_TICK.register(this::handleTick);
	}

	private void handleTick(MinecraftClient client) {
		if (toggleKeyBinding == null) {
			return;
		}

		while (toggleKeyBinding.wasPressed()) {
			playersHidden = !playersHidden;
			notifyToggle(client);
		}
	}

	private static void notifyToggle(MinecraftClient client) {
		if (client.inGameHud == null) {
			return;
		}

		Text message = playersHidden
				? Text.translatable("message.playerhider.hidden")
				: Text.translatable("message.playerhider.visible");

		client.inGameHud.setOverlayMessage(message, false);
	}
}
