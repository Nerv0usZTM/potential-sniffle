package com.katan.playerhider.mixin;

import com.katan.playerhider.PlayerHiderClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Sprawia, że gdy {@link PlayerHiderClient#playersHidden} jest ustawione na
 * true, wszyscy gracze poza Tobą stają się dla renderera "niewidzialni"
 * (dokładnie tak, jak przy efekcie mikstury Niewidzialności - klient po
 * prostu ich nie rysuje, łącznie z nickiem nad głową). To działa wyłącznie
 * lokalnie: serwer i inni gracze nadal widzą się normalnie, zmienia się
 * tylko to, co renderuje się na Twoim ekranie.
 *
 * Celowo mixinujemy stabilną, publiczną metodę {@code Entity#isInvisible()}
 * zamiast wewnętrznych metod renderera - te bywają przebudowywane między
 * wersjami Minecrafta, a isInvisible() jest niezmienne od lat, więc mod jest
 * dużo mniej podatny na "zepsucie" przy aktualizacji gry.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {

	@Inject(method = "isInvisible", at = @At("RETURN"), cancellable = true)
	private void playerhider$hideOtherPlayers(CallbackInfoReturnable<Boolean> cir) {
		if (!PlayerHiderClient.playersHidden) {
			return;
		}

		Entity self = (Entity) (Object) this;

		if (!(self instanceof PlayerEntity)) {
			return;
		}

		MinecraftClient client = MinecraftClient.getInstance();
		if (self == client.player) {
			// Nigdy nie ukrywaj samego siebie (np. w widoku trzecioosobowym).
			return;
		}

		cir.setReturnValue(true);
	}
}
