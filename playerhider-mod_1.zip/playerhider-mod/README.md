# Player Hider (Fabric mod)

Mod na Fabric do Minecrafta **1.21.11**. Naciśnięcie przypisanego klawisza sprawia,
że przestajesz widzieć **innych** graczy na swoim ekranie (tak jakby mieli
Niewidzialność) — również grając na cudzym serwerze multiplayer. Efekt jest
**wyłącznie lokalny**: inni gracze nadal widzą siebie nawzajem normalnie,
zmienia się tylko to, co Ty widzisz. Nie trzeba niczego instalować na
serwerze. Ponowne naciśnięcie klawisza przywraca widoczność.

## Dlaczego kompilacja nie mogła się odbyć tutaj

Ten projekt powstał w środowisku bez dostępu do serwerów Mojanga i Fabric
(maven.fabricmc.net, piston-meta.mojang.com itd.), więc `gradle` nie mógł
pobrać Minecrafta ani bibliotek Fabric, by faktycznie zbudować `.jar`. Kod
źródłowy przeszedł jednak sprawdzenie składni (javac) — jedyne błędy to
brakujące na tej maszynie zależności zewnętrzne, nie błędy w kodzie.

Projekt zawiera gotowy workflow GitHub Actions (`.github/workflows/build.yml`),
który buduje `.jar` automatycznie w chmurze GitHuba — zobacz sekcję
"Budowanie przez GitHub Actions (bez terminala u siebie)" poniżej.

## Budowanie przez GitHub Actions (bez terminala u siebie)

1. Załóż darmowe konto na [github.com](https://github.com), jeśli jeszcze go
   nie masz.
2. Utwórz nowe, **puste** repozytorium (przycisk "New" na stronie głównej
   GitHuba) — nazwij je np. `playerhider-mod`, nie zaznaczaj "Add a README".
3. Na stronie nowego, pustego repozytorium kliknij link **"uploading an
   existing file"** (pojawia się w instrukcji "quick setup").
4. Rozpakuj ZIP z tym projektem u siebie na dysku i przeciągnij **całą
   zawartość** folderu `playerhider-mod` (wszystkie pliki i podfoldery,
   łącznie z ukrytym folderem `.github`) na stronę uploadu w przeglądarce.
   Uwaga: przeglądarki czasem nie pokazują ukrytych folderów (`.github`) w
   oknie "wybierz pliki" — bezpieczniej jest **zaznaczyć cały rozpakowany
   folder `playerhider-mod` i przeciągnąć go myszką** bezpośrednio na stronę
   GitHuba, wtedy `.github` trafi razem z resztą.
5. Kliknij zielony przycisk **"Commit changes"** na dole strony.
6. Przejdź do zakładki **"Actions"** na górze repozytorium — build
   uruchomi się automatycznie po chwili (albo kliknij workflow "Build
   Player Hider mod" po lewej i przycisk **"Run workflow"**, jeśli sam się
   nie uruchomił).
7. Poczekaj 2–5 minut, aż zadanie dostanie zieloną "ptaszek" (sukces).
   Kliknij w nie, a na dole strony znajdziesz sekcję **"Artifacts"** z
   plikiem `playerhider-jar` — pobierz go, w środku będzie gotowy
   `playerhider-1.0.0.jar`.

Ten sam `.jar` możesz potem wrzucić do folderu `mods` zgodnie z sekcją "Jak
zagrać z modem" poniżej.

## Wymagania (jeśli wolisz zbudować lokalnie, przez terminal)

- **Java 21** (Minecraft 1.21.x wymaga Javy 21 — sprawdź: `java -version`)
- Połączenie z internetem (pierwszy build pobierze Minecrafta, mapowania i
  Fabric API)

## Jak zbudować mod

1. Rozpakuj archiwum projektu.
2. W terminalu, w folderze projektu, uruchom:
   - Linux/macOS: `./gradlew build`
   - Windows: `gradlew.bat build`
3. Po zakończeniu gotowy plik `.jar` znajdziesz w:
   `build/libs/playerhider-1.0.0.jar`

Pierwsze uruchomienie potrwa dłużej (Gradle pobiera Minecrafta i zależności).

## Jak zagrać z modem

1. Zainstaluj [Fabric Loader](https://fabricmc.net/use/) dla Minecrafta **1.21.11**.
2. Pobierz i wrzuć do folderu `mods` w `.minecraft`:
   - zbudowany `playerhider-1.0.0.jar` (z kroku wyżej),
   - [Fabric API](https://modrinth.com/mod/fabric-api/version/0.141.2+1.21.11) w wersji `0.141.2+1.21.11` (mod wymaga Fabric API — to osobny, oficjalny plik do pobrania).
3. Uruchom Minecrafta z profilem Fabric 1.21.11.
4. Wejdź w **Opcje → Sterowanie** i przewiń do kategorii **"Player Hider"** —
   domyślnie klawisz jest **nieprzypisany**, więc musisz sam wybrać przycisk
   (zgodnie z tym, o co prosiłeś — Ty decydujesz, pod jakim klawiszem ma to
   działać).
5. W grze naciśnij wybrany klawisz — inni gracze znikną z Twojego ekranu
   (zobaczysz komunikat na pasku). Naciśnij ponownie, żeby ich przywrócić.

## Jak to działa (skrót techniczny)

- `PlayerHiderClient` rejestruje keybinding i trzyma globalny stan
  `playersHidden` (włącz/wyłącz).
- `EntityMixin` podmienia wynik metody `Entity#isInvisible()` na `true` dla
  wszystkich graczy poza Tobą, gdy `playersHidden == true` — to ta sama
  mechanika renderowania, co przy mikstury Niewidzialności, więc jest bardzo
  stabilna między wersjami gry.
- Wszystko dzieje się tylko w kliencie (`environment: client` w
  `fabric.mod.json`) — mod nic nie zmienia po stronie serwera ani u innych
  graczy.

## Ważna uwaga

Ponieważ wykorzystujemy tę samą mechanikę co mikstura Niewidzialności, gdy
gracz ma na sobie pancerz albo trzyma coś w ręku, może być lekko widoczny
(np. unoszący się hełm) — to normalne zachowanie silnika gry, nie błąd moda.

## Struktura projektu

```
playerhider-mod/
├── build.gradle
├── gradle.properties
├── settings.gradle
├── gradlew / gradlew.bat
└── src/
    ├── main/resources/
    │   ├── fabric.mod.json
    │   └── assets/playerhider/lang/ (en_us.json, pl_pl.json)
    └── client/
        ├── java/com/katan/playerhider/
        │   ├── PlayerHiderClient.java   (keybinding + stan)
        │   └── mixin/EntityMixin.java   (ukrywanie renderowania)
        └── resources/playerhider.client.mixins.json
```
